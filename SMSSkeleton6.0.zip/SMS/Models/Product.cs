﻿namespace SMS.Models
{
    public class Product
    {
    }
}
