﻿namespace SMS.Models
{
    public class User
    {
    }
}
